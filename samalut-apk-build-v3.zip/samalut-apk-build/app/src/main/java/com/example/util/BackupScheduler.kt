package com.example.util

import android.content.Context
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkInfo
import androidx.work.WorkManager
import java.util.Calendar
import java.util.concurrent.TimeUnit

object BackupScheduler {

    const val UNIQUE_WORK_NAME = "SamalutSecurityPeriodicAutoBackup"
    const val TAG_AUTO_BACKUP = "periodic_auto_backup"
    private const val PREFS_NAME = "samalut_backup_prefs"
    private const val KEY_AUTO_BACKUP_ENABLED = "auto_backup_enabled"

    /**
     * جدولة النسخ الاحتياطي التلقائي ليعمل دورياً (كل أسبوع - يوم الجمعة الساعة 11:00 مساءً)
     */
    fun schedulePeriodicBackup(context: Context) {
        val initialDelay = calculateDelayUntilNextFridayNight()

        val workRequest = PeriodicWorkRequestBuilder<AutoBackupWorker>(
            7, TimeUnit.DAYS, // تكرار أسبوعي
            1, TimeUnit.HOURS // نافذة مرنة
        )
            .setInitialDelay(initialDelay, TimeUnit.MILLISECONDS)
            .addTag(TAG_AUTO_BACKUP)
            .build()

        WorkManager.getInstance(context).enqueueUniquePeriodicWork(
            UNIQUE_WORK_NAME,
            ExistingPeriodicWorkPolicy.UPDATE,
            workRequest
        )

        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit()
            .putBoolean(KEY_AUTO_BACKUP_ENABLED, true)
            .apply()
    }

    /**
     * إلغاء جدولة النسخ الاحتياطي الدوري
     */
    fun cancelPeriodicBackup(context: Context) {
        WorkManager.getInstance(context).cancelUniqueWork(UNIQUE_WORK_NAME)
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit()
            .putBoolean(KEY_AUTO_BACKUP_ENABLED, false)
            .apply()
    }

    /**
     * هل النسخ الاحتياطي التلقائي مفعل؟
     */
    fun isAutoBackupEnabled(context: Context): Boolean {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .getBoolean(KEY_AUTO_BACKUP_ENABLED, true) // مفعل افتراضياً
    }

    /**
     * حساب الوقت المتبقي حتى موعد يوم الجمعة القادم الساعة 11:00 مساءً (23:00)
     */
    fun calculateDelayUntilNextFridayNight(): Long {
        val now = Calendar.getInstance()
        val target = Calendar.getInstance().apply {
            set(Calendar.DAY_OF_WEEK, Calendar.FRIDAY)
            set(Calendar.HOUR_OF_DAY, 23) // 11:00 PM
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }

        // إذا كان الموعد المستهدف قد انقضى هذا الأسبوع، نجدوله للجمعة القادمة
        if (target.before(now) || target.timeInMillis <= now.timeInMillis) {
            target.add(Calendar.DAY_OF_YEAR, 7)
        }

        return (target.timeInMillis - now.timeInMillis).coerceAtLeast(0)
    }

    /**
     * معلومات عن آخر موعد نسخ احتياطي
     */
    fun getLastBackupDate(context: Context): String {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .getString("last_backup_date", "لم يتم إنشاء نسخة بعد") ?: "لم يتم إنشاء نسخة بعد"
    }
}
