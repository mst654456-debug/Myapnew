package com.example.ui.screens

import com.example.ui.components.IncidentReportPanel

import com.example.data.preferences.AdminConfig

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.IncidentStatus
import com.example.data.model.SecurityIncident
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun IncidentsScreen(
    incidents: List<SecurityIncident>,
    searchQuery: String,
    selectedStatus: IncidentStatus?,
    onSearchChange: (String) -> Unit,
    onStatusFilter: (IncidentStatus?) -> Unit,
    onIncidentClick: (Long) -> Unit,
    onEditIncident: (Long) -> Unit,
    onDeleteIncident: (SecurityIncident) -> Unit,
    onAddIncidentClick: () -> Unit,
    allIncidents: List<SecurityIncident> = incidents,
    adminConfig: AdminConfig = AdminConfig(),
    onBackClick: () -> Unit
) {
    var incidentToDelete by remember { mutableStateOf<SecurityIncident?>(null) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "سجل الوقائع والأحداث الأمنية",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )
                },
                navigationIcon = {
                    IconButton(
                        onClick = onBackClick,
                        modifier = Modifier.testTag("incidents_back_button")
                    ) {
                        Icon(Icons.Default.ArrowForward, contentDescription = "رجوع")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = EduBlue,
                    titleContentColor = Color.White,
                    navigationIconContentColor = Color.White
                )
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = onAddIncidentClick,
                containerColor = EduGreen,
                contentColor = Color.White,
                modifier = Modifier.testTag("fab_add_incident_list")
            ) {
                Icon(Icons.Default.Add, contentDescription = "إضافة واقعة")
            }
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .background(MaterialTheme.colorScheme.background)
        ) {
            // Search field
            OutlinedTextField(
                value = searchQuery,
                onValueChange = onSearchChange,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 10.dp)
                    .testTag("incident_search_field"),
                placeholder = { Text("بحث بعنوان الواقعة، المدرسة، أو الأطراف...") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = EduBlue) },
                trailingIcon = {
                    if (searchQuery.isNotBlank()) {
                        IconButton(onClick = { onSearchChange("") }) {
                            Icon(Icons.Default.Close, contentDescription = "مسح")
                        }
                    }
                },
                singleLine = true,
                shape = RoundedCornerShape(14.dp)
            )

            // Status Filter Chips (الكل / جاري المتابعة / تم الحل / مغلقة)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
                    .padding(horizontal = 16.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FilterChip(
                    selected = selectedStatus == null,
                    onClick = { onStatusFilter(null) },
                    label = { Text("كل الحالات (${incidents.size})") }
                )
                FilterChip(
                    selected = selectedStatus == IncidentStatus.IN_PROGRESS,
                    onClick = { onStatusFilter(IncidentStatus.IN_PROGRESS) },
                    label = { Text("جاري المتابعة ⏳") }
                )
                FilterChip(
                    selected = selectedStatus == IncidentStatus.RESOLVED,
                    onClick = { onStatusFilter(IncidentStatus.RESOLVED) },
                    label = { Text("تم الحل ✅") }
                )
                FilterChip(
                    selected = selectedStatus == IncidentStatus.CLOSED,
                    onClick = { onStatusFilter(IncidentStatus.CLOSED) },
                    label = { Text("مغلقة 📁") }
                )
            }

            IncidentReportPanel(
                incidents = allIncidents,
                adminConfig = adminConfig,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)
            )

            Spacer(modifier = Modifier.height(4.dp))

            // Incidents List
            if (incidents.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            imageVector = Icons.Default.CheckCircleOutline,
                            contentDescription = null,
                            tint = EduGreen,
                            modifier = Modifier.size(64.dp)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "لا توجد وقائع مسجلة مطابقة للبحث",
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "الحالة الأمنية مستقرة تماماً",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(incidents, key = { it.id }) { incident ->
                        IncidentColorCard(
                            incident = incident,
                            onClick = { onIncidentClick(incident.id) },
                            onEditClick = { onEditIncident(incident.id) },
                            onDeleteClick = { incidentToDelete = incident }
                        )
                    }
                }
            }
        }
    }

    // Delete Confirmation Dialog
    if (incidentToDelete != null) {
        val inc = incidentToDelete!!
        AlertDialog(
            onDismissRequest = { incidentToDelete = null },
            title = {
                Text(
                    text = "تأكيد حذف الواقعة",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                )
            },
            text = {
                Text("هل أنت متأكد من حذف واقعة '${inc.title}' نهائياً من السجلات؟")
            },
            confirmButton = {
                Button(
                    onClick = {
                        onDeleteIncident(inc)
                        incidentToDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                    modifier = Modifier.testTag("confirm_delete_incident_list_dialog")
                ) {
                    Text("حذف نهائياً")
                }
            },
            dismissButton = {
                TextButton(onClick = { incidentToDelete = null }) {
                    Text("إلغاء")
                }
            }
        )
    }
}

@Composable
fun IncidentColorCard(
    incident: SecurityIncident,
    onClick: () -> Unit,
    onEditClick: () -> Unit,
    onDeleteClick: () -> Unit
) {
    val statusColor = when (incident.status) {
        IncidentStatus.IN_PROGRESS -> StatusInProgress
        IncidentStatus.RESOLVED -> StatusResolved
        IncidentStatus.CLOSED -> StatusClosed
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .border(
                width = 1.dp,
                color = statusColor.copy(alpha = 0.5f),
                shape = RoundedCornerShape(16.dp)
            )
            .testTag("incident_card_${incident.id}"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Header Row: Status Badge & Photos count
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    color = statusColor.copy(alpha = 0.15f),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text(
                        text = incident.status.displayNameAr,
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                        color = statusColor,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                    )
                }

                if (incident.imageUris.isNotEmpty()) {
                    Surface(
                        color = EduBlue.copy(alpha = 0.12f),
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                        ) {
                            Icon(Icons.Default.PhotoLibrary, contentDescription = null, tint = EduBlue, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "${incident.imageUris.size} صور مرفقة",
                                style = MaterialTheme.typography.labelSmall,
                                color = EduBlue
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Title
            Text(
                text = incident.title,
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = MaterialTheme.colorScheme.onSurface
            )

            Spacer(modifier = Modifier.height(6.dp))

            // School
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.School,
                    contentDescription = null,
                    tint = EduBlue,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = incident.schoolName,
                    style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold),
                    color = MaterialTheme.colorScheme.onSurface
                )
            }

            if (incident.partiesInvolved.isNotBlank()) {
                Spacer(modifier = Modifier.height(6.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.PeopleOutline,
                        contentDescription = null,
                        tint = EduGoldDark,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "الأطراف: ${incident.partiesInvolved}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1
                    )
                }
            }

            Divider(modifier = Modifier.padding(vertical = 10.dp), color = MaterialTheme.colorScheme.outlineVariant)

            // Date, Supervisor, and Quick Edit / Delete Buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "${incident.dateString} - ${incident.timeString}",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = incident.supervisor,
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                        color = EduBlueDark
                    )
                }

                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    // Quick Edit Button
                    IconButton(
                        onClick = onEditClick,
                        modifier = Modifier
                            .size(36.dp)
                            .testTag("card_edit_incident_${incident.id}")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Edit,
                            contentDescription = "تعديل",
                            tint = EduBlue,
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    // Quick Delete Button
                    IconButton(
                        onClick = onDeleteClick,
                        modifier = Modifier
                            .size(36.dp)
                            .testTag("card_delete_incident_${incident.id}")
                    ) {
                        Icon(
                            imageVector = Icons.Default.DeleteOutline,
                            contentDescription = "حذف",
                            tint = MaterialTheme.colorScheme.error,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }
        }
    }
}
