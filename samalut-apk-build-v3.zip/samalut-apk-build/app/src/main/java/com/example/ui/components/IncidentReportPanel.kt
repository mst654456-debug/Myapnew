package com.example.ui.components

import android.app.DatePickerDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.model.SecurityIncident
import com.example.data.preferences.AdminConfig
import com.example.ui.theme.EduBlue
import com.example.ui.theme.EduGreen
import com.example.util.ReportExporter
import com.example.util.WhatsAppHelper
import java.util.Calendar
import java.util.Date

/**
 * لوحة تقارير الأحداث داخل شاشة الأحداث: تقرير يومي أو تقرير شهري.
 * مطوية افتراضياً حتى لا تزاحم قائمة الأحداث.
 */
@Composable
fun IncidentReportPanel(
    incidents: List<SecurityIncident>,
    adminConfig: AdminConfig,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var expanded by remember { mutableStateOf(false) }
    var period by remember { mutableStateOf(ReportExporter.ReportPeriod.DAILY) }
    var selectedDate by remember { mutableStateOf(Date()) }

    val isDaily = period == ReportExporter.ReportPeriod.DAILY
    val periodIncidents = remember(period, selectedDate, incidents) {
        ReportExporter.filterForPeriod(period, incidents, selectedDate)
    }
    val dateText = remember(period, selectedDate) {
        ReportExporter.periodDateText(period, selectedDate)
    }
    val reportText = remember(period, selectedDate, incidents, adminConfig) {
        ReportExporter.generateReportText(period, incidents, adminConfig, selectedDate)
    }
    val isEmpty = periodIncidents.isEmpty()

    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { expanded = !expanded },
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Assessment, contentDescription = null, tint = EduBlue)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "تقارير الأحداث: يومي أو شهري",
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                    )
                }
                Icon(
                    imageVector = if (expanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                    contentDescription = if (expanded) "إخفاء التقارير" else "إظهار التقارير",
                    tint = EduBlue
                )
            }

            if (expanded) {
                Spacer(modifier = Modifier.height(12.dp))

                // نوع التقرير
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(
                        selected = isDaily,
                        onClick = { period = ReportExporter.ReportPeriod.DAILY },
                        label = { Text("تقرير يومي") }
                    )
                    FilterChip(
                        selected = !isDaily,
                        onClick = { period = ReportExporter.ReportPeriod.MONTHLY },
                        label = { Text("تقرير شهري") }
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                // اليوم أو الشهر المحدد
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = if (isDaily) "تاريخ اليوم المحدد:" else "الشهر المحدد:",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = dateText,
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                            color = EduBlue
                        )
                    }
                    Button(
                        onClick = { pickReportDate(context, selectedDate) { selectedDate = it } },
                        colors = ButtonDefaults.buttonColors(containerColor = EduBlue),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(Icons.Default.CalendarToday, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("تغيير", style = MaterialTheme.typography.labelSmall)
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // اختصارات سريعة
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = { selectedDate = Date() },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text(if (isDaily) "اليوم" else "هذا الشهر", style = MaterialTheme.typography.labelSmall)
                    }
                    OutlinedButton(
                        onClick = {
                            selectedDate = Calendar.getInstance().apply {
                                time = Date()
                                add(if (isDaily) Calendar.DAY_OF_YEAR else Calendar.MONTH, -1)
                            }.time
                        },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text(if (isDaily) "أمس" else "الشهر الماضي", style = MaterialTheme.typography.labelSmall)
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                Text(
                    text = if (isEmpty) "لا توجد أحداث مسجلة في هذه الفترة (يصدر التقرير كإفادة خلو أحداث)" else "عدد الأحداث في الفترة: ${periodIncidents.size}",
                    style = MaterialTheme.typography.bodySmall,
                    color = if (isEmpty) EduGreen else MaterialTheme.colorScheme.onSurface
                )

                Spacer(modifier = Modifier.height(12.dp))

                // تصدير Word و PDF متاح للتقرير اليومي
                if (isDaily) {
                    Button(
                        onClick = {
                            val docxFile = ReportExporter.generateDailyReportDocx(
                                context = context,
                                date = selectedDate,
                                incidents = incidents,
                                adminConfig = adminConfig
                            )
                            ReportExporter.shareGeneratedFile(
                                context = context,
                                file = docxFile,
                                mimeType = "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                                title = if (isEmpty) "إفادة خلو أحداث Word" else "تقرير الأحداث Word"
                            )
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2B579A)),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                    ) {
                        Icon(Icons.Default.Description, contentDescription = null, tint = Color.White)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (isEmpty) "إفادة خلو الأحداث Word (DOCX)" else "تقرير الأحداث Word (DOCX)",
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Button(
                        onClick = {
                            val pdfFile = ReportExporter.generateDailyReportPdf(
                                context = context,
                                date = selectedDate,
                                incidents = incidents,
                                adminConfig = adminConfig
                            )
                            ReportExporter.shareGeneratedFile(
                                context = context,
                                file = pdfFile,
                                mimeType = "application/pdf",
                                title = if (isEmpty) "إفادة خلو أحداث PDF" else "تقرير الأحداث PDF"
                            )
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = EduBlue),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                    ) {
                        Icon(Icons.Default.PictureAsPdf, contentDescription = null, tint = Color.White)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (isEmpty) "إفادة خلو الأحداث PDF" else "تقرير الأحداث PDF",
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                }

                // طباعة وواتساب (يعمل للتقرير اليومي والشهري)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedButton(
                        onClick = {
                            ReportExporter.exportToPdfPrint(
                                context = context,
                                period = period,
                                incidents = incidents,
                                adminConfig = adminConfig,
                                selectedDate = selectedDate
                            )
                        },
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                    ) {
                        Icon(Icons.Default.Print, contentDescription = null, tint = EduBlue)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("طباعة / PDF", style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold))
                    }
                    Button(
                        onClick = { WhatsAppHelper.shareTextToWhatsApp(context, reportText) },
                        colors = ButtonDefaults.buttonColors(containerColor = EduGreen),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                    ) {
                        Icon(Icons.Default.Chat, contentDescription = null, tint = Color.White)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("واتساب", style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold))
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedButton(
                        onClick = { copyReportText(context, reportText) },
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Default.ContentCopy, contentDescription = null, tint = EduBlue, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("نسخ النص", style = MaterialTheme.typography.labelMedium)
                    }
                    OutlinedButton(
                        onClick = {
                            val csv = ReportExporter.exportIncidentsToCsv(periodIncidents)
                            ReportExporter.shareCsvToExternal(context, csv)
                        },
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Default.TableChart, contentDescription = null, tint = EduGreen, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Excel / CSV", style = MaterialTheme.typography.labelMedium)
                    }
                }
            }
        }
    }
}

private fun pickReportDate(context: Context, current: Date, onPicked: (Date) -> Unit) {
    val cal = Calendar.getInstance().apply { time = current }
    DatePickerDialog(
        context,
        { _, year, month, day ->
            onPicked(Calendar.getInstance().apply { set(year, month, day) }.time)
        },
        cal.get(Calendar.YEAR),
        cal.get(Calendar.MONTH),
        cal.get(Calendar.DAY_OF_MONTH)
    ).show()
}

private fun copyReportText(context: Context, text: String) {
    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
    clipboard?.setPrimaryClip(ClipData.newPlainText("تقرير الأحداث", text))
    Toast.makeText(context, "تم نسخ التقرير إلى الحافظة", Toast.LENGTH_SHORT).show()
}
