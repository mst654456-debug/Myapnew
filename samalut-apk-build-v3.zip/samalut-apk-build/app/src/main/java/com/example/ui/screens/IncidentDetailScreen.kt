package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.model.IncidentStatus
import com.example.data.model.SecurityIncident
import com.example.ui.components.FullScreenImageViewerDialog
import com.example.ui.theme.*
import com.example.util.WhatsAppHelper

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun IncidentDetailScreen(
    incident: SecurityIncident?,
    onUpdateStatus: (SecurityIncident, IncidentStatus) -> Unit,
    onEditIncident: (Long) -> Unit,
    onDeleteIncident: (SecurityIncident) -> Unit,
    onBackClick: () -> Unit
) {
    val context = LocalContext.current
    var showDeleteConfirm by remember { mutableStateOf(false) }
    var selectedPhotoForPreview by remember { mutableStateOf<String?>(null) }

    if (incident == null) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            CircularProgressIndicator()
        }
        return
    }

    val statusColor = when (incident.status) {
        IncidentStatus.IN_PROGRESS -> StatusInProgress
        IncidentStatus.RESOLVED -> StatusResolved
        IncidentStatus.CLOSED -> StatusClosed
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "تفاصيل الواقعة الأمنية",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )
                },
                navigationIcon = {
                    IconButton(
                        onClick = onBackClick,
                        modifier = Modifier.testTag("incident_detail_back_button")
                    ) {
                        Icon(Icons.Default.ArrowForward, contentDescription = "رجوع")
                    }
                },
                actions = {
                    // Edit Incident Button
                    IconButton(
                        onClick = { onEditIncident(incident.id) },
                        modifier = Modifier.testTag("incident_detail_edit_button")
                    ) {
                        Icon(Icons.Default.Edit, contentDescription = "تعديل الواقعة", tint = Color.White)
                    }
                    // Share to WhatsApp Button
                    IconButton(
                        onClick = {
                            val text = """
                                🚨 *إخطار أمني - إدارة سمالوط التعليمية*
                                • الواقعة: ${incident.title}
                                • المدرسة: ${incident.schoolName}
                                • الحالة: ${incident.status.displayNameAr}
                                • الأطراف: ${incident.partiesInvolved}
                                • الإجراء المتخذ: ${incident.actionTaken}
                                • التاريخ: ${incident.dateString} ${incident.timeString}
                                • مسؤول الأمن: ${incident.supervisor}
                            """.trimIndent()
                            WhatsAppHelper.shareTextToWhatsApp(context, text)
                        },
                        modifier = Modifier.testTag("incident_detail_share_button")
                    ) {
                        Icon(Icons.Default.Share, contentDescription = "مشاركة للواتساب", tint = Color.White)
                    }
                    // Delete Incident Button
                    IconButton(
                        onClick = { showDeleteConfirm = true },
                        modifier = Modifier.testTag("incident_detail_delete_button")
                    ) {
                        Icon(Icons.Default.DeleteOutline, contentDescription = "حذف الواقعة", tint = Color.White)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = EduBlue,
                    titleContentColor = Color.White,
                    navigationIconContentColor = Color.White
                )
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .background(MaterialTheme.colorScheme.background)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Badges Header: Status Badge
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    color = statusColor.copy(alpha = 0.15f),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text(
                        text = "الحالة الإدارية: ${incident.status.displayNameAr}",
                        style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                        color = statusColor,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                    )
                }

                Text(
                    text = "${incident.dateString} - ${incident.timeString}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            // Title & Core Data Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = incident.title,
                        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    InfoRow(icon = Icons.Default.School, label = "المدرسة", value = incident.schoolName)
                    if (incident.partiesInvolved.isNotBlank()) {
                        InfoRow(icon = Icons.Default.Groups, label = "الأطراف المعنية", value = incident.partiesInvolved)
                    }
                    InfoRow(icon = Icons.Default.CalendarToday, label = "التاريخ والوقت", value = "${incident.dateString} الساعة ${incident.timeString}")
                    InfoRow(icon = Icons.Default.VerifiedUser, label = "مسؤول الأمن المتابع", value = incident.supervisor)
                }
            }

            // Description Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "وصف وملابسات الواقعة",
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                        color = EduBlue,
                        modifier = Modifier.padding(bottom = 8.dp)
                    )
                    Text(
                        text = incident.description,
                        style = MaterialTheme.typography.bodyMedium,
                        lineHeight = 22.sp
                    )
                }
            }

            // Action Taken Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "الإجراء المتخذ من إدارة الأمن",
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                        color = EduGreen,
                        modifier = Modifier.padding(bottom = 8.dp)
                    )
                    Text(
                        text = incident.actionTaken.ifBlank { "قيد التحقيق والمتابعة الأمنية" },
                        style = MaterialTheme.typography.bodyMedium,
                        lineHeight = 22.sp
                    )
                }
            }

            // Multiple Images Gallery Preview with Click to Full Screen Viewer
            if (incident.imageUris.isNotEmpty()) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "صور المعاينة والمستندات المرفقة (${incident.imageUris.size})",
                                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                            )
                            Text(
                                text = "اضغط للمعاينة الكاملة",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        LazyRow(
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            items(incident.imageUris) { uri ->
                                Box(
                                    modifier = Modifier
                                        .size(130.dp)
                                        .clip(RoundedCornerShape(12.dp))
                                        .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(12.dp))
                                        .clickable { selectedPhotoForPreview = uri }
                                ) {
                                    AsyncImage(
                                        model = uri,
                                        contentDescription = "صورة الواقعة",
                                        contentScale = ContentScale.Crop,
                                        modifier = Modifier.fillMaxSize()
                                    )
                                    Box(
                                        modifier = Modifier
                                            .align(Alignment.BottomStart)
                                            .padding(6.dp)
                                            .background(Color.Black.copy(alpha = 0.5f), CircleShape)
                                            .size(26.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            Icons.Default.ZoomIn,
                                            contentDescription = "تكبير",
                                            tint = Color.White,
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Status Change Actions (تم الحل / جاري المتابعة / مغلقة)
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "تحديث حالة الواقعة (استخدام إداري):",
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                        modifier = Modifier.padding(bottom = 10.dp)
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = { onUpdateStatus(incident, IncidentStatus.RESOLVED) },
                            colors = ButtonDefaults.buttonColors(containerColor = EduGreen),
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(10.dp),
                            enabled = incident.status != IncidentStatus.RESOLVED
                        ) {
                            Text("تم الحل ✅", style = MaterialTheme.typography.labelSmall)
                        }

                        Button(
                            onClick = { onUpdateStatus(incident, IncidentStatus.IN_PROGRESS) },
                            colors = ButtonDefaults.buttonColors(containerColor = EduBlue),
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(10.dp),
                            enabled = incident.status != IncidentStatus.IN_PROGRESS
                        ) {
                            Text("جاري ⏳", style = MaterialTheme.typography.labelSmall)
                        }

                        Button(
                            onClick = { onUpdateStatus(incident, IncidentStatus.CLOSED) },
                            colors = ButtonDefaults.buttonColors(containerColor = StatusClosed),
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(10.dp),
                            enabled = incident.status != IncidentStatus.CLOSED
                        ) {
                            Text("مغلقة 📁", style = MaterialTheme.typography.labelSmall)
                        }
                    }
                }
            }

            // Edit & Delete Action Buttons Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Button(
                    onClick = { onEditIncident(incident.id) },
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .testTag("edit_incident_action_button"),
                    colors = ButtonDefaults.buttonColors(containerColor = EduBlue),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(Icons.Default.Edit, contentDescription = null)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("تعديل الواقعة", fontWeight = FontWeight.Bold)
                }

                OutlinedButton(
                    onClick = { showDeleteConfirm = true },
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .testTag("delete_incident_action_button"),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error),
                    border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.error),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(Icons.Default.DeleteOutline, contentDescription = null)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("حذف الواقعة", fontWeight = FontWeight.Bold)
                }
            }

            // Share to WhatsApp Button
            Button(
                onClick = {
                    val text = """
                        🚨 *إدارة أمن الإدارة التعليمية بسمالوط*
                        📋 *إخطار واقعة:* ${incident.title}
                        🏫 *المدرسة:* ${incident.schoolName}
                        📌 *الحالة:* ${incident.status.displayNameAr}
                        👥 *الأطراف:* ${incident.partiesInvolved}
                        📝 *الوصف:* ${incident.description}
                        ⚖️ *الإجراء:* ${incident.actionTaken}
                        📅 *التاريخ:* ${incident.dateString} ${incident.timeString}
                        ✍️ *مسؤول الأمن:* ${incident.supervisor}
                    """.trimIndent()
                    WhatsAppHelper.shareTextToWhatsApp(context, text)
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
                    .testTag("incident_detail_whatsapp_share"),
                colors = ButtonDefaults.buttonColors(containerColor = EduGreen),
                shape = RoundedCornerShape(14.dp)
            ) {
                Icon(Icons.Default.Chat, contentDescription = null, tint = Color.White)
                Spacer(modifier = Modifier.width(8.dp))
                Text("مشاركة تفاصيل الواقعة عبر واتساب 🟢", fontWeight = FontWeight.Bold)
            }

            Spacer(modifier = Modifier.height(20.dp))
        }
    }

    // Full Screen Image Viewer Modal Dialog
    if (selectedPhotoForPreview != null) {
        FullScreenImageViewerDialog(
            imageUri = selectedPhotoForPreview!!,
            onDismiss = { selectedPhotoForPreview = null }
        )
    }

    // Delete Confirmation Dialog
    if (showDeleteConfirm) {
        AlertDialog(
            onDismissRequest = { showDeleteConfirm = false },
            title = {
                Text(
                    text = "تأكيد حذف الواقعة",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                )
            },
            text = { Text("هل أنت متأكد من رغبتك في حذف واقعة: '${incident.title}' نهائياً من سجلات إدارة الأمن؟") },
            confirmButton = {
                Button(
                    onClick = {
                        showDeleteConfirm = false
                        onDeleteIncident(incident)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                    modifier = Modifier.testTag("confirm_delete_incident_button")
                ) {
                    Text("حذف نهائياً")
                }
            },
            dismissButton = {
                TextButton(
                    onClick = { showDeleteConfirm = false },
                    modifier = Modifier.testTag("cancel_delete_incident_button")
                ) {
                    Text("إلغاء")
                }
            }
        )
    }
}

@Composable
private fun InfoRow(
    icon: ImageVector,
    label: String,
    value: String
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(imageVector = icon, contentDescription = null, tint = EduBlue, modifier = Modifier.size(18.dp))
        Spacer(modifier = Modifier.width(8.dp))
        Text(
            text = "$label: ",
            style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold),
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Text(
            text = value,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurface
        )
    }
}
