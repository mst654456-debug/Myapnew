package com.example.util

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import java.util.Locale

/**
 * أدوات الإحداثيات الجغرافية للمدارس:
 *  - تحويل نص الإحداثي (بالأرقام العربية أو الإنجليزية) إلى رقم والتحقق من نطاقه
 *  - فتح موقع المدرسة في تطبيق الخرائط المثبت على الهاتف
 */
object GeoHelper {

    /**
     * يرجع null إذا كان النص فارغاً أو غير صحيح أو خارج النطاق المسموح
     * (خط العرض بين -90 و 90، وخط الطول بين -180 و 180).
     */
    fun parseCoordinate(raw: String, isLatitude: Boolean): Double? {
        val normalized = buildString {
            raw.trim().forEach { ch ->
                when (ch) {
                    in '\u0660'..'\u0669' -> append('0' + (ch - '\u0660'))
                    in '\u06F0'..'\u06F9' -> append('0' + (ch - '\u06F0'))
                    '\u066B', '\u060C', ',' -> append('.')
                    ' ' -> Unit
                    else -> append(ch)
                }
            }
        }
        if (normalized.isEmpty()) return null
        val value = normalized.toDoubleOrNull() ?: return null
        val limit = if (isLatitude) 90.0 else 180.0
        return if (value >= -limit && value <= limit) value else null
    }

    /** عرض الإحداثي بستة أرقام عشرية بصيغة ثابتة */
    fun formatCoordinate(value: Double): String = "%.6f".format(Locale.US, value)

    /** فتح الموقع في تطبيق الخرائط */
    fun openInMaps(context: Context, latitude: Double, longitude: Double, label: String) {
        val uri = Uri.parse("geo:$latitude,$longitude?q=$latitude,$longitude(${Uri.encode(label)})")
        val intent = Intent(Intent.ACTION_VIEW, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try {
            context.startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(context, "لا يوجد تطبيق خرائط لفتح الموقع", Toast.LENGTH_SHORT).show()
        }
    }
}
