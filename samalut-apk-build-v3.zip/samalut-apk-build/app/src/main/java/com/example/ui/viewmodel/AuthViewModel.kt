package com.example.ui.viewmodel

import com.example.data.preferences.AdminInfo

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class AuthState(
    val isAuthenticated: Boolean = false,
    val adminName: String = "",
    val role: String = "مسؤول أمن الإدارة التعليمية",
    val administration: String = "إدارة سمالوط التعليمية",
    val email: String = "security.samalut@edu.eg",
    val isLoading: Boolean = false,
    val errorMessage: String? = null
)

class AuthViewModel : ViewModel() {

    private val _authState = MutableStateFlow(AuthState())
    val authState: StateFlow<AuthState> = _authState.asStateFlow()

    /** تسجيل الدخول بعد نجاح التحقق بالبصمة (أو قفل الجهاز). */
    fun loginWithBiometric() {
        _authState.value = _authState.value.copy(
            isAuthenticated = true,
            adminName = AdminInfo.officerLabel,
            isLoading = false,
            errorMessage = null
        )
    }

    fun logout() {
        _authState.value = _authState.value.copy(
            isAuthenticated = false,
            errorMessage = null
        )
    }

    fun clearError() {
        _authState.value = _authState.value.copy(errorMessage = null)
    }
}
