package com.example.ui.components

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.model.School
import com.example.data.model.SchoolTripEntity
import com.example.data.model.SecurityIncident
import com.example.data.model.Teacher
import com.example.data.model.TeacherLeaveEntity
import com.example.data.model.TeacherPenaltyEntity
import com.example.ui.theme.EduBlue
import com.example.ui.theme.EduBlueDark
import com.example.util.SmartQueryEngine
import com.example.util.WhatsAppHelper

/**
 * المساعد الذكي:
 *  - وضع "من بيانات البرنامج": استعلام فوري في المدارس والمعلمين والإجازات والرحلات والجزاءات.
 *  - مربع البحث أعلى النافذة مع زر بحث وإدخال صوتي، والنتائج قابلة للتمرير.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SmartQueryAssistantDialog(
    schools: List<School>,
    teachers: List<Teacher>,
    incidents: List<SecurityIncident>,
    leaves: List<TeacherLeaveEntity>,
    penalties: List<TeacherPenaltyEntity>,
    trips: List<SchoolTripEntity>,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current

    var queryText by remember { mutableStateOf("") }
    var currentResponse by remember { mutableStateOf<SmartQueryEngine.QueryResponse?>(null) }

    val sampleQueries = listOf(
        "مين عنده إجازة سارية في المدارس؟",
        "إيه الرحلات والفعاليات المدرسية المسجلة؟",
        "من هم المعلمون الحاصلون على جزاءات؟"
    )

    fun executeQuery(text: String) {
        if (text.isBlank()) return
        currentResponse = SmartQueryEngine.processNaturalLanguageQuery(
            query = text,
            schools = schools,
            teachers = teachers,
            incidents = incidents,
            leaves = leaves,
            penalties = penalties,
            trips = trips
        )
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.96f)
                .fillMaxHeight(0.94f)
                .testTag("dialog_ai_assistant"),
            shape = RoundedCornerShape(20.dp),
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 6.dp
        ) {
            Column(modifier = Modifier.fillMaxSize()) {
                // Header نحيف
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            Brush.horizontalGradient(
                                colors = listOf(Color(0xFF1E3A8A), Color(0xFF3B82F6), Color(0xFF8B5CF6))
                            )
                        )
                        .padding(horizontal = 12.dp, vertical = 8.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.AutoAwesome,
                                contentDescription = null,
                                tint = Color(0xFFFFD700),
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "المساعد الذكي لأمن سمالوط",
                                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                color = Color.White,
                                maxLines = 1
                            )
                        }
                        IconButton(
                            onClick = onDismiss,
                            modifier = Modifier
                                .size(30.dp)
                                .background(Color.White.copy(alpha = 0.15f), CircleShape)
                        ) {
                            Icon(Icons.Default.Close, contentDescription = "إغلاق", tint = Color.White, modifier = Modifier.size(18.dp))
                        }
                    }
                }

                // مربع البحث في الأعلى + زر البحث + إدخال صوتي
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 10.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    CompactSearchField(
                        value = queryText,
                        onValueChange = { queryText = it },
                        placeholder = "اكتب سؤالك (مثال: مين عنده إجازة؟)",
                        onSearch = { executeQuery(queryText) },
                        onVoiceResult = {
                            queryText = it
                            executeQuery(it)
                        },
                        accent = Color(0xFF8B5CF6),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("input_ai_query")
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = { executeQuery(queryText) },
                        enabled = queryText.isNotBlank(),
                        shape = RoundedCornerShape(20.dp),
                        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 0.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E3A8A)),
                        modifier = Modifier
                            .height(40.dp)
                            .testTag("btn_ai_search")
                    ) {
                        Text("بحث", fontWeight = FontWeight.Bold)
                    }
                }

                HorizontalDivider(
                    modifier = Modifier.padding(top = 6.dp),
                    color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)
                )

                // منطقة النتائج (قابلة للتمرير)
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 8.dp)
                ) {
                    val response = currentResponse
                    when {

                        response != null -> {
                            LazyColumn(
                                modifier = Modifier.fillMaxSize(),
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                item {
                                    Surface(
                                        shape = RoundedCornerShape(12.dp),
                                        color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.25f),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(10.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Icon(Icons.Default.HelpOutline, contentDescription = null, tint = EduBlue, modifier = Modifier.size(18.dp))
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Text(
                                                text = response.question,
                                                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                                                color = EduBlueDark
                                            )
                                        }
                                    }
                                }

                                item {
                                    Card(
                                        shape = RoundedCornerShape(16.dp),
                                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Column(modifier = Modifier.padding(14.dp)) {
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.SpaceBetween,
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Row(
                                                    verticalAlignment = Alignment.CenterVertically,
                                                    modifier = Modifier.weight(1f)
                                                ) {
                                                    Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = Color(0xFF8B5CF6), modifier = Modifier.size(18.dp))
                                                    Spacer(modifier = Modifier.width(6.dp))
                                                    Text(
                                                        text = response.title,
                                                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                                        color = Color(0xFF1E3A8A)
                                                    )
                                                }

                                                if (response.rawResultsCount >= 0) {
                                                    Surface(
                                                        color = Color(0xFF1E3A8A).copy(alpha = 0.1f),
                                                        shape = RoundedCornerShape(6.dp)
                                                    ) {
                                                        Text(
                                                            text = "${response.rawResultsCount} نتائج",
                                                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                                            color = EduBlue,
                                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                                        )
                                                    }
                                                }
                                            }

                                            Spacer(modifier = Modifier.height(8.dp))
                                            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
                                            Spacer(modifier = Modifier.height(8.dp))

                                            SelectionContainer {
                                                Text(
                                                    text = response.formattedDetails,
                                                    style = MaterialTheme.typography.bodySmall.copy(lineHeight = 20.sp),
                                                    color = MaterialTheme.colorScheme.onSurface
                                                )
                                            }

                                            Spacer(modifier = Modifier.height(12.dp))

                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                                            ) {
                                                Button(
                                                    onClick = {
                                                        WhatsAppHelper.shareTextToWhatsApp(context, response.shareableText)
                                                    },
                                                    modifier = Modifier.weight(1f),
                                                    shape = RoundedCornerShape(8.dp),
                                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2E7D32))
                                                ) {
                                                    Icon(Icons.Default.Chat, contentDescription = null, modifier = Modifier.size(16.dp))
                                                    Spacer(modifier = Modifier.width(6.dp))
                                                    Text("واتساب", style = MaterialTheme.typography.labelSmall, maxLines = 1)
                                                }

                                                OutlinedButton(
                                                    onClick = {
                                                        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                                        clipboard.setPrimaryClip(ClipData.newPlainText("المساعد الذكي", response.shareableText))
                                                        Toast.makeText(context, "تم نسخ الرد", Toast.LENGTH_SHORT).show()
                                                    },
                                                    modifier = Modifier.weight(1f),
                                                    shape = RoundedCornerShape(8.dp)
                                                ) {
                                                    Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(16.dp))
                                                    Spacer(modifier = Modifier.width(4.dp))
                                                    Text("نسخ", style = MaterialTheme.typography.labelSmall, maxLines = 1)
                                                }
                                            }

                                        }
                                    }
                                }
                            }
                        }

                        else -> {
                            Column(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .padding(16.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Psychology,
                                    contentDescription = null,
                                    tint = Color(0xFF8B5CF6),
                                    modifier = Modifier.size(44.dp)
                                )
                                Spacer(modifier = Modifier.height(10.dp))
                                Text(
                                    text = "اكتب سؤالك أو اضغط على الميكروفون وتكلم",
                                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                    color = MaterialTheme.colorScheme.onSurface,
                                    textAlign = TextAlign.Center
                                )
                                    Spacer(modifier = Modifier.height(12.dp))
                                    sampleQueries.forEach { sample ->
                                        Text(
                                            text = "• $sample",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = Color(0xFF6D4FD6),
                                            modifier = Modifier
                                                .clickable {
                                                    queryText = sample
                                                    executeQuery(sample)
                                                }
                                                .padding(vertical = 5.dp)
                                        )
                                    }
                            }
                        }
                    }
                }
            }
        }
    }
}
