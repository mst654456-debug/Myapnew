package com.example.util

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.net.Uri
import android.media.ExifInterface
import java.io.File
import java.io.FileOutputStream

/**
 * حفظ صورة المعلم داخل مجلد التطبيق (بدون تعديل قاعدة البيانات حتى لا تضيع أي بيانات قائمة).
 * اسم الملف: <teacherId>_<timestamp>.jpg ، وآخر ملف بنفس رقم المعلم هو الصورة الحالية.
 */
object TeacherPhotoHelper {

    private const val MAX_SIDE = 640

    private fun dir(context: Context): File =
        File(context.filesDir, "teacher_photos").apply { if (!exists()) mkdirs() }

    /** مسار آخر صورة للمعلم أو نص فارغ إن لم توجد. */
    fun getPhotoPath(context: Context, teacherId: Long): String {
        val prefix = "${teacherId}_"
        return dir(context).listFiles { f -> f.isFile && f.name.startsWith(prefix) }
            ?.maxByOrNull { it.lastModified() }
            ?.absolutePath
            .orEmpty()
    }

    /** نسخ الصورة المختارة بعد تصغيرها وتصحيح اتجاهها، وحذف الصور القديمة. */
    fun savePhoto(context: Context, uri: Uri, teacherId: Long): Boolean {
        return try {
            // 1) قراءة الأبعاد فقط
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return false

            var sample = 1
            while (bounds.outWidth / sample > MAX_SIDE * 2 || bounds.outHeight / sample > MAX_SIDE * 2) sample *= 2

            // 2) فك الترميز بحجم مناسب
            val opts = BitmapFactory.Options().apply { inSampleSize = sample }
            var bitmap = context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
                ?: return false

            // 3) تصحيح الاتجاه حسب EXIF
            val rotation = try {
                context.contentResolver.openInputStream(uri)?.use { input ->
                    when (ExifInterface(input).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)) {
                        ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                        ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                        ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                        else -> 0f
                    }
                } ?: 0f
            } catch (e: Exception) {
                0f
            }

            // 4) تصغير نهائي + تدوير
            val scale = MAX_SIDE.toFloat() / maxOf(bitmap.width, bitmap.height)
            val matrix = Matrix().apply {
                if (scale < 1f) postScale(scale, scale)
                if (rotation != 0f) postRotate(rotation)
            }
            if (!matrix.isIdentity) {
                bitmap = Bitmap.createBitmap(bitmap, 0, 0, bitmap.width, bitmap.height, matrix, true)
            }

            val oldFiles = dir(context).listFiles { f -> f.isFile && f.name.startsWith("${teacherId}_") }.orEmpty()
            val target = File(dir(context), "${teacherId}_${System.currentTimeMillis()}.jpg")
            FileOutputStream(target).use { bitmap.compress(Bitmap.CompressFormat.JPEG, 88, it) }
            oldFiles.forEach { it.delete() }
            true
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }

    fun deletePhoto(context: Context, teacherId: Long) {
        dir(context).listFiles { f -> f.isFile && f.name.startsWith("${teacherId}_") }
            ?.forEach { it.delete() }
    }
}
