package com.example.util

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.ParcelFileDescriptor
import android.provider.OpenableColumns
import android.widget.Toast
import androidx.core.content.FileProvider
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object AttachmentHelper {

    /**
     * توليد صورة معاينة للصفحة الأولى لملف PDF عبر Android PdfRenderer الأصلي
     */
    fun renderPdfFirstPage(filePath: String, maxWidth: Int = 800, maxHeight: Int = 1000): Bitmap? {
        return try {
            val file = File(filePath)
            if (!file.exists() || !isPdf(filePath)) return null
            val pfd = ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY)
            val renderer = PdfRenderer(pfd)
            if (renderer.pageCount > 0) {
                val page = renderer.openPage(0)
                val scale = minOf(maxWidth.toFloat() / page.width, maxHeight.toFloat() / page.height, 1.0f)
                val targetW = (page.width * scale).toInt().coerceAtLeast(100)
                val targetH = (page.height * scale).toInt().coerceAtLeast(100)

                val bitmap = Bitmap.createBitmap(targetW, targetH, Bitmap.Config.ARGB_8888)
                page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                page.close()
                renderer.close()
                pfd.close()
                bitmap
            } else {
                renderer.close()
                pfd.close()
                null
            }
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    /**
     * نسخ ملف من Uri خارجي (مستند PDF أو صورة) إلى مجلد التطبيق الداخلي لضمان بقائه متاحاً دائماً
     */
    fun saveUriToInternalStorage(context: Context, uri: Uri, prefix: String = "doc"): String? {
        return try {
            val originalName = getFileNameFromUri(context, uri) ?: "${prefix}_${System.currentTimeMillis()}"
            val extension = if (originalName.contains(".")) {
                originalName.substringAfterLast(".", "")
            } else {
                context.contentResolver.getType(uri)?.substringAfterLast("/") ?: "bin"
            }

            val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
            val cleanName = originalName.substringBeforeLast(".")
                .replace("[^a-zA-Z0-9ء-ي_\\-]".toRegex(), "_")
                .take(30)
            val fileName = "${prefix}_${timeStamp}_${cleanName}.${extension}"

            val attachmentsDir = File(context.filesDir, "attachments").apply {
                if (!exists()) mkdirs()
            }
            val destinationFile = File(attachmentsDir, fileName)

            context.contentResolver.openInputStream(uri)?.use { inputStream ->
                FileOutputStream(destinationFile).use { outputStream ->
                    inputStream.copyTo(outputStream)
                }
            }
            destinationFile.absolutePath
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    fun getFileNameFromUri(context: Context, uri: Uri): String? {
        var name: String? = null
        if (uri.scheme == "content") {
            try {
                context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                    val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (nameIndex != -1 && cursor.moveToFirst()) {
                        name = cursor.getString(nameIndex)
                    }
                }
            } catch (e: Exception) {
                // Ignore fallback to path
            }
        }
        if (name == null) {
            name = uri.path?.let { p ->
                val cut = p.lastIndexOf('/')
                if (cut != -1) p.substring(cut + 1) else p
            }
        }
        return name
    }

    /**
     * استخراج اسم العرض للملف من المسار
     */
    fun getDisplayName(filePath: String): String {
        val file = File(filePath)
        return if (file.name.isNotBlank()) file.name else filePath.substringAfterLast('/')
    }

    /**
     * معرفة ما إذا كان الملف هو PDF
     */
    fun isPdf(filePath: String): Boolean {
        return filePath.endsWith(".pdf", ignoreCase = true)
    }

    /**
     * معرفة ما إذا كان الملف صورة
     */
    fun isImage(filePath: String): Boolean {
        val ext = filePath.substringAfterLast('.', "").lowercase()
        return ext in listOf("jpg", "jpeg", "png", "webp", "bmp", "gif")
    }

    /**
     * حجم الملف بصيغة مقروءة (KB أو MB)
     */
    fun getFileSizeFormatted(filePath: String): String {
        val file = File(filePath)
        if (!file.exists()) return "0 KB"
        val bytes = file.length()
        return if (bytes >= 1024 * 1024) {
            String.format(Locale.US, "%.1f MB", bytes / (1024.0 * 1024.0))
        } else {
            val kb = (bytes / 1024).coerceAtLeast(1)
            "$kb KB"
        }
    }

    /**
     * تاريخ تعديل الملف
     */
    fun getFileDateFormatted(filePath: String): String {
        val file = File(filePath)
        if (!file.exists()) return ""
        return SimpleDateFormat("yyyy/MM/dd HH:mm", Locale.getDefault()).format(Date(file.lastModified()))
    }

    /**
     * حذف الملف من التخزين الداخلي
     */
    fun deleteAttachmentFile(filePath: String): Boolean {
        return try {
            val file = File(filePath)
            if (file.exists()) file.delete() else true
        } catch (e: Exception) {
            false
        }
    }

    /**
     * مشاركة الملف عبر تطبيقات أخرى (واتساب، بريد، بلوتوث...)
     */
    fun shareAttachment(context: Context, filePath: String) {
        try {
            val file = File(filePath)
            if (!file.exists()) {
                Toast.makeText(context, "الملف غير موجود في الذاكرة", Toast.LENGTH_SHORT).show()
                return
            }
            val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
            val mimeType = if (isPdf(filePath)) "application/pdf" else if (isImage(filePath)) "image/*" else "*/*"
            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                type = mimeType
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            context.startActivity(Intent.createChooser(shareIntent, "مشاركة الملف المرفق"))
        } catch (e: Exception) {
            Toast.makeText(context, "تعذر مشاركة الملف: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    /**
     * فتح المستند أو الصورة عبر تطبيق عارض مناسب في النظام
     */
    fun openAttachment(context: Context, filePathOrUri: String) {
        try {
            val file = File(filePathOrUri)
            val uri: Uri = if (file.exists()) {
                FileProvider.getUriForFile(
                    context,
                    "${context.packageName}.fileprovider",
                    file
                )
            } else {
                Uri.parse(filePathOrUri)
            }

            val mimeType = if (isPdf(filePathOrUri)) {
                "application/pdf"
            } else {
                val ext = filePathOrUri.substringAfterLast('.', "")
                when (ext.lowercase()) {
                    "jpg", "jpeg" -> "image/jpeg"
                    "png" -> "image/png"
                    "webp" -> "image/webp"
                    "doc" -> "application/msword"
                    "docx" -> "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
                    else -> "*/*"
                }
            }

            val intent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, mimeType)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(Intent.createChooser(intent, "فتح المرفق"))
        } catch (e: Exception) {
            Toast.makeText(context, "تعذر فتح الملف المرفق: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    /**
     * مشاركة الملف مباشرة عبر واتساب
     */
    fun shareToWhatsApp(context: Context, filePath: String) {
        try {
            val file = File(filePath)
            if (!file.exists()) {
                Toast.makeText(context, "الملف غير موجود في الذاكرة", Toast.LENGTH_SHORT).show()
                return
            }
            val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
            val mimeType = if (isPdf(filePath)) "application/pdf" else if (isImage(filePath)) "image/*" else "*/*"

            val whatsappIntent = Intent(Intent.ACTION_SEND).apply {
                type = mimeType
                `package` = "com.whatsapp"
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(whatsappIntent)
        } catch (e: Exception) {
            // Fallback to chooser if WhatsApp is not directly resolvable
            shareAttachment(context, filePath)
        }
    }

    /**
     * طباعة الملف مباشرة عبر Android PrintManager
     */
    fun printAttachment(context: Context, filePath: String) {
        try {
            val file = File(filePath)
            if (!file.exists()) {
                Toast.makeText(context, "الملف غير موجود للطباعة", Toast.LENGTH_SHORT).show()
                return
            }

            if (isImage(filePath)) {
                val printManager = context.getSystemService(Context.PRINT_SERVICE) as? android.print.PrintManager
                val bitmap = BitmapFactory.decodeFile(filePath)
                if (printManager != null && bitmap != null) {
                    val printAdapter = object : android.print.PrintDocumentAdapter() {
                        override fun onLayout(
                            oldAttributes: android.print.PrintAttributes?,
                            newAttributes: android.print.PrintAttributes?,
                            cancellationSignal: android.os.CancellationSignal?,
                            callback: LayoutResultCallback?,
                            extras: android.os.Bundle?
                        ) {
                            if (cancellationSignal?.isCanceled == true) {
                                callback?.onLayoutCancelled()
                                return
                            }
                            val info = android.print.PrintDocumentInfo.Builder(file.name)
                                .setContentType(android.print.PrintDocumentInfo.CONTENT_TYPE_DOCUMENT)
                                .setPageCount(1)
                                .build()
                            callback?.onLayoutFinished(info, true)
                        }

                        override fun onWrite(
                            pages: Array<out android.print.PageRange>?,
                            destination: ParcelFileDescriptor?,
                            cancellationSignal: android.os.CancellationSignal?,
                            callback: WriteResultCallback?
                        ) {
                            try {
                                val pdfDoc = android.graphics.pdf.PdfDocument()
                                val pageInfo = android.graphics.pdf.PdfDocument.PageInfo.Builder(bitmap.width, bitmap.height, 1).create()
                                val page = pdfDoc.startPage(pageInfo)
                                page.canvas.drawBitmap(bitmap, 0f, 0f, null)
                                pdfDoc.finishPage(page)
                                FileOutputStream(destination?.fileDescriptor).use { out ->
                                    pdfDoc.writeTo(out)
                                }
                                pdfDoc.close()
                                callback?.onWriteFinished(arrayOf(android.print.PageRange.ALL_PAGES))
                            } catch (e: Exception) {
                                callback?.onWriteFailed(e.message)
                            }
                        }
                    }
                    printManager.print("طباعة_${file.name}", printAdapter, null)
                } else {
                    openAttachment(context, filePath)
                }
            } else if (isPdf(filePath)) {
                val printManager = context.getSystemService(Context.PRINT_SERVICE) as? android.print.PrintManager
                if (printManager != null) {
                    val printAdapter = object : android.print.PrintDocumentAdapter() {
                        override fun onLayout(
                            oldAttributes: android.print.PrintAttributes?,
                            newAttributes: android.print.PrintAttributes?,
                            cancellationSignal: android.os.CancellationSignal?,
                            callback: LayoutResultCallback?,
                            extras: android.os.Bundle?
                        ) {
                            if (cancellationSignal?.isCanceled == true) {
                                callback?.onLayoutCancelled()
                                return
                            }
                            val info = android.print.PrintDocumentInfo.Builder(file.name)
                                .setContentType(android.print.PrintDocumentInfo.CONTENT_TYPE_DOCUMENT)
                                .build()
                            callback?.onLayoutFinished(info, true)
                        }

                        override fun onWrite(
                            pages: Array<out android.print.PageRange>?,
                            destination: ParcelFileDescriptor?,
                            cancellationSignal: android.os.CancellationSignal?,
                            callback: WriteResultCallback?
                        ) {
                            try {
                                FileInputStream(file).use { input ->
                                    FileOutputStream(destination?.fileDescriptor).use { output ->
                                        val buf = ByteArray(8192)
                                        var bytesRead: Int
                                        while (input.read(buf).also { bytesRead = it } >= 0) {
                                            if (cancellationSignal?.isCanceled == true) {
                                                callback?.onWriteCancelled()
                                                return
                                            }
                                            output.write(buf, 0, bytesRead)
                                        }
                                    }
                                }
                                callback?.onWriteFinished(arrayOf(android.print.PageRange.ALL_PAGES))
                            } catch (e: Exception) {
                                callback?.onWriteFailed(e.message)
                            }
                        }
                    }
                    printManager.print("طباعة_${file.name}", printAdapter, null)
                } else {
                    Toast.makeText(context, "خدمة الطباعة غير متاحة على الجهاز", Toast.LENGTH_SHORT).show()
                }
            } else {
                openAttachment(context, filePath)
            }
        } catch (e: Exception) {
            Toast.makeText(context, "تعذر تشغيل الطباعة: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }
}
