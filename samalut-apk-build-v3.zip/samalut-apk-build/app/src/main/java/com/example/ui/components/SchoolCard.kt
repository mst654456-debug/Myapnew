package com.example.ui.components

import com.example.data.preferences.AdminInfo

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.School
import com.example.data.model.SchoolStage
import com.example.ui.theme.*
import com.example.util.WhatsAppHelper

/**
 * بطاقة المدرسة المطورة والشاملة مع أزرار الاتصال والواتساب، الإحصائيات، والتعديل والحذف
 */
@Composable
fun SchoolCard(
    school: School,
    onSchoolClick: () -> Unit,
    onEditSchool: () -> Unit,
    onDeleteSchool: () -> Unit,
    onUpdateSchool: ((School) -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var showDeleteConfirmDialog by remember { mutableStateOf(false) }
    var viewingAttachment by remember { mutableStateOf<String?>(null) }
    var showAttachOptions by remember { mutableStateOf(false) }

    // Pickers for direct attachment from SchoolCard
    val docPicker = androidx.activity.compose.rememberLauncherForActivityResult(
        contract = androidx.activity.result.contract.ActivityResultContracts.OpenMultipleDocuments()
    ) { uris ->
        val newPaths = uris.mapNotNull { com.example.util.AttachmentHelper.saveUriToInternalStorage(context, it, "school_doc") }
        if (newPaths.isNotEmpty() && onUpdateSchool != null) {
            onUpdateSchool(school.copy(attachedFiles = school.attachedFiles + newPaths))
        }
    }

    val imgPicker = androidx.activity.compose.rememberLauncherForActivityResult(
        contract = androidx.activity.result.contract.ActivityResultContracts.PickMultipleVisualMedia()
    ) { uris ->
        val newPaths = uris.mapNotNull { com.example.util.AttachmentHelper.saveUriToInternalStorage(context, it, "school_img") }
        if (newPaths.isNotEmpty() && onUpdateSchool != null) {
            onUpdateSchool(school.copy(attachedFiles = school.attachedFiles + newPaths))
        }
    }

    if (viewingAttachment != null) {
        AttachmentViewerDialog(
            filePath = viewingAttachment!!,
            onDismiss = { viewingAttachment = null },
            onDelete = {
                val target = viewingAttachment
                if (target != null && onUpdateSchool != null) {
                    onUpdateSchool(school.copy(attachedFiles = school.attachedFiles.filter { it != target }))
                }
                viewingAttachment = null
            }
        )
    }

    val stageColor = when (school.stage) {
        SchoolStage.KINDERGARTEN -> Color(0xFFE91E63)
        SchoolStage.PRIMARY -> Color(0xFF00897B)
        SchoolStage.PREPARATORY -> EduBlue
        SchoolStage.GENERAL_SECONDARY -> Color(0xFF6A1B9A)
        SchoolStage.TECHNICAL_SECONDARY -> Color(0xFFE65100)
        SchoolStage.COMMUNITY_EDUCATION -> Color(0xFF00838F)
        SchoolStage.PRIVATE_SCHOOLS -> Color(0xFFC2185B)
    }

    // Delete Confirmation Dialog
    if (showDeleteConfirmDialog) {
        AlertDialog(
            onDismissRequest = { showDeleteConfirmDialog = false },
            icon = {
                Icon(
                    imageVector = Icons.Default.WarningAmber,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.error,
                    modifier = Modifier.size(36.dp)
                )
            },
            title = {
                Text(
                    text = "تأكيد حذف المدرسة",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                )
            },
            text = {
                Text(
                    text = "هل أنت متأكد من حذف مدرسة «${school.name}» نهائياً من سجلات إدارة سمالوط؟ لا يمكن التراجع عن هذا الإجراء.",
                    style = MaterialTheme.typography.bodyMedium
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        showDeleteConfirmDialog = false
                        onDeleteSchool()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.testTag("btn_confirm_delete_school")
                ) {
                    Text("نعم، حذف المدرسة", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                OutlinedButton(
                    onClick = { showDeleteConfirmDialog = false },
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("إلغاء")
                }
            }
        )
    }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .clickable { onSchoolClick() }
            .testTag("school_card_${school.id}"),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Header: School Name, Stage Badge, Location
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Box(
                        modifier = Modifier
                            .size(46.dp)
                            .background(stageColor.copy(alpha = 0.12f), RoundedCornerShape(12.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.School,
                            contentDescription = null,
                            tint = stageColor,
                            modifier = Modifier.size(26.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = school.name,
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "${school.governorate} • ${school.administration}" +
                                    if (school.address.isNotBlank()) " • ${school.address}" else "",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                Surface(
                    color = stageColor.copy(alpha = 0.15f),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text(
                        text = school.stage.displayNameAr,
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                        color = stageColor,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }

            HorizontalDivider(
                modifier = Modifier.padding(vertical = 12.dp),
                color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.6f)
            )

            // Section 1: School Administration (المدير، الوكلاء، مسؤول الأمن) with Call & WhatsApp
            Column(
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // المدير (Principal)
                ContactRowItem(
                    roleTitle = "المدير",
                    name = school.principalName.ifBlank { "غير مسجل" },
                    phone = school.principalPhone,
                    roleIcon = Icons.Default.Person,
                    roleColor = EduBlue,
                    onCall = {
                        if (school.principalPhone.isNotBlank()) {
                            WhatsAppHelper.makePhoneCall(context, school.principalPhone)
                        }
                    },
                    onWhatsApp = {
                        if (school.principalPhone.isNotBlank()) {
                            val msg = "السلام عليكم ورحمة الله وبركاته يا فندم أ/ ${school.principalName}، معك أمن الإدارة التعليمية بسمالوط (مسؤول الأمن: ${AdminInfo.officerLabel}) بخصوص متابعة مدرسة ${school.name}."
                            WhatsAppHelper.openWhatsApp(context, school.principalPhone, msg)
                        }
                    }
                )

                // الوكلاء (Vice Principals - 1 to 4)
                if (school.vicePrincipals.isNotEmpty()) {
                    school.vicePrincipals.forEachIndexed { index, vp ->
                        val roleLabel = if (school.vicePrincipals.size == 1) "الوكيل" else "الوكيل (${index + 1})"
                        ContactRowItem(
                            roleTitle = roleLabel,
                            name = vp.name.ifBlank { "غير مسجل" },
                            phone = vp.phone,
                            roleIcon = Icons.Default.Group,
                            roleColor = Color(0xFF5E35B1),
                            onCall = {
                                if (vp.phone.isNotBlank()) {
                                    WhatsAppHelper.makePhoneCall(context, vp.phone)
                                }
                            },
                            onWhatsApp = {
                                if (vp.phone.isNotBlank()) {
                                    val msg = "السلام عليكم ورحمة الله وبركاته يا فندم أ/ ${vp.name}، معك أمن الإدارة التعليمية بسمالوط (مسؤول الأمن: ${AdminInfo.officerLabel}) بخصوص مدرسة ${school.name}."
                                    WhatsAppHelper.openWhatsApp(context, vp.phone, msg)
                                }
                            }
                        )
                    }
                }

                // مسؤول أمن المدرسة (Security Officer)
                ContactRowItem(
                    roleTitle = "مسؤول الأمن",
                    name = school.securityOfficerName.ifBlank { "غير مسجل" },
                    phone = school.securityOfficerPhone,
                    roleIcon = Icons.Default.Security,
                    roleColor = EduGreen,
                    onCall = {
                        if (school.securityOfficerPhone.isNotBlank()) {
                            WhatsAppHelper.makePhoneCall(context, school.securityOfficerPhone)
                        }
                    },
                    onWhatsApp = {
                        if (school.securityOfficerPhone.isNotBlank()) {
                            val msg = "السلام عليكم ورحمة الله وبركاته زميلنا الفاضل أ/ ${school.securityOfficerName}، معك أمن الإدارة التعليمية بسمالوط (${AdminInfo.officerLabel}) لمتابعة الحالة الأمنية في ${school.name}."
                            WhatsAppHelper.openWhatsApp(context, school.securityOfficerPhone, msg)
                        }
                    }
                )

                // مسئول الأزمات والكوارث (Crisis Manager)
                ContactRowItem(
                    roleTitle = "مسئول الأزمات",
                    name = school.crisisManagerName.ifBlank { "غير مسجل" },
                    phone = school.crisisManagerPhone,
                    roleIcon = Icons.Default.Warning,
                    roleColor = Color(0xFFE65100),
                    onCall = {
                        if (school.crisisManagerPhone.isNotBlank()) {
                            WhatsAppHelper.makePhoneCall(context, school.crisisManagerPhone)
                        }
                    },
                    onWhatsApp = {
                        if (school.crisisManagerPhone.isNotBlank()) {
                            val msg = "السلام عليكم ورحمة الله وبركاته أ/ ${school.crisisManagerName}، معك أمن الإدارة التعليمية بسمالوط (${AdminInfo.officerLabel}) بخصوص خطة الأزمات والكوارث بمدرسة ${school.name}."
                            WhatsAppHelper.openWhatsApp(context, school.crisisManagerPhone, msg)
                        }
                    }
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Section 2: Statistics & Equipment (الفصول، المعلمين، العمال، المباني، الطفايات، الكاميرات)
            Surface(
                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Text(
                        text = "التجهيزات والأعداد والإحصائيات:",
                        style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(bottom = 6.dp)
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        StatItemPill(icon = Icons.Default.MeetingRoom, label = "فصول", count = school.classroomsCount, tint = EduBlue)
                        StatItemPill(icon = Icons.Default.School, label = "معلمين", count = school.teachersCount, tint = Color(0xFF00897B))
                        StatItemPill(icon = Icons.Default.Engineering, label = "عمال", count = school.workersCount, tint = Color(0xFF5D4037))
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        StatItemPill(icon = Icons.Default.Apartment, label = "مباني", count = school.buildingsCount, tint = EduBlueDark)
                        StatItemPill(icon = Icons.Default.FireExtinguisher, label = "طفايات", count = school.extinguishersCount, tint = Color(0xFFD32F2F))
                        StatItemPill(icon = Icons.Default.Videocam, label = "كاميرات", count = school.camerasCount, tint = EduGreen)
                    }
                }
            }

            // Section: Attached Files Preview on School Card
            if (school.attachedFiles.isNotEmpty()) {
                Spacer(modifier = Modifier.height(10.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "المستندات والصور المرفقة (${school.attachedFiles.size}):",
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                        color = EduBlue
                    )
                    Text(
                        text = "اضغط للمعاينة",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Spacer(modifier = Modifier.height(4.dp))
                androidx.compose.foundation.lazy.LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    items(school.attachedFiles) { path ->
                        val isPdf = com.example.util.AttachmentHelper.isPdf(path)
                        Surface(
                            modifier = Modifier.clickable { viewingAttachment = path },
                            shape = RoundedCornerShape(8.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = if (isPdf) Icons.Default.PictureAsPdf else Icons.Default.Image,
                                    contentDescription = null,
                                    tint = if (isPdf) Color(0xFFD32F2F) else EduBlue,
                                    modifier = Modifier.size(14.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = com.example.util.AttachmentHelper.getDisplayName(path),
                                    style = MaterialTheme.typography.labelSmall,
                                    maxLines = 1
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Section 3: Action Buttons (تعديل - إرفاق - حذف - تفاصيل)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // زر تفاصيل المدرسة
                FilledTonalButton(
                    onClick = onSchoolClick,
                    shape = RoundedCornerShape(10.dp),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                    modifier = Modifier.weight(1.1f)
                ) {
                    Text("التفاصيل", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.width(3.dp))
                    Icon(Icons.Default.ChevronLeft, contentDescription = null, modifier = Modifier.size(15.dp))
                }

                // زر إرفاق مستند/صورة
                OutlinedButton(
                    onClick = { showAttachOptions = true },
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = EduGreen),
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 6.dp),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("btn_attach_school_card_${school.id}")
                ) {
                    Icon(Icons.Default.AttachFile, contentDescription = null, modifier = Modifier.size(15.dp))
                    Spacer(modifier = Modifier.width(3.dp))
                    Text("إرفاق", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                }

                // زر تعديل المدرسة
                OutlinedButton(
                    onClick = onEditSchool,
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = EduBlue),
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 6.dp),
                    modifier = Modifier
                        .weight(0.9f)
                        .testTag("btn_edit_school_${school.id}")
                ) {
                    Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(15.dp))
                    Spacer(modifier = Modifier.width(3.dp))
                    Text("تعديل", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                }

                // زر حذف المدرسة
                IconButton(
                    onClick = { showDeleteConfirmDialog = true },
                    modifier = Modifier
                        .size(38.dp)
                        .testTag("btn_delete_school_${school.id}")
                ) {
                    Icon(Icons.Default.DeleteOutline, contentDescription = "حذف المدرسة", tint = MaterialTheme.colorScheme.error)
                }
            }

            // Quick Attach Selection Dialog
            if (showAttachOptions) {
                AlertDialog(
                    onDismissRequest = { showAttachOptions = false },
                    title = { Text("إرفاق ملف لمدرسة ${school.name}") },
                    text = {
                        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Text("اختر نوع الملف المراد إرفاقه وحفظه في سجل المدرسة:")
                            Button(
                                onClick = {
                                    showAttachOptions = false
                                    docPicker.launch(arrayOf("application/pdf", "*/*"))
                                },
                                modifier = Modifier.fillMaxWidth(),
                                colors = ButtonDefaults.buttonColors(containerColor = EduBlue),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Icon(Icons.Default.PictureAsPdf, contentDescription = null)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("إرفاق مستند PDF / قرار إداري")
                            }

                            Button(
                                onClick = {
                                    showAttachOptions = false
                                    imgPicker.launch(
                                        androidx.activity.result.PickVisualMediaRequest(
                                            androidx.activity.result.contract.ActivityResultContracts.PickVisualMedia.ImageOnly
                                        )
                                    )
                                },
                                modifier = Modifier.fillMaxWidth(),
                                colors = ButtonDefaults.buttonColors(containerColor = EduGreen),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Icon(Icons.Default.PhotoLibrary, contentDescription = null)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("إرفاق صورة من المعرض")
                            }
                        }
                    },
                    confirmButton = {},
                    dismissButton = {
                        TextButton(onClick = { showAttachOptions = false }) {
                            Text("إلغاء")
                        }
                    }
                )
            }
        }
    }
}

/**
 * صف لعرض بيانات المسؤول (مدير / وكيل / أمن) مع أزرار الاتصال والواتساب
 */
@Composable
private fun ContactRowItem(
    roleTitle: String,
    name: String,
    phone: String,
    roleIcon: ImageVector,
    roleColor: Color,
    onCall: () -> Unit,
    onWhatsApp: () -> Unit
) {
    Surface(
        color = MaterialTheme.colorScheme.surface,
        shape = RoundedCornerShape(10.dp),
        border = androidx.compose.foundation.BorderStroke(0.8.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 10.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                Box(
                    modifier = Modifier
                        .size(30.dp)
                        .background(roleColor.copy(alpha = 0.12f), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = roleIcon,
                        contentDescription = null,
                        tint = roleColor,
                        modifier = Modifier.size(16.dp)
                    )
                }
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "$roleTitle: ",
                            style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                            color = roleColor
                        )
                        Text(
                            text = name,
                            style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Medium),
                            color = MaterialTheme.colorScheme.onSurface,
                            maxLines = 1
                        )
                    }
                    if (phone.isNotBlank()) {
                        Text(
                            text = phone,
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            // Quick Call & WhatsApp Action Buttons
            if (phone.isNotBlank()) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // WhatsApp Button 🟢
                    IconButton(
                        onClick = onWhatsApp,
                        modifier = Modifier
                            .size(32.dp)
                            .background(Color(0xFFE8F5E9), CircleShape)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Chat,
                            contentDescription = "مراسلة واتساب",
                            tint = Color(0xFF2E7D32),
                            modifier = Modifier.size(16.dp)
                        )
                    }

                    // Call Button 📞
                    IconButton(
                        onClick = onCall,
                        modifier = Modifier
                            .size(32.dp)
                            .background(EduBlue.copy(alpha = 0.12f), CircleShape)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Phone,
                            contentDescription = "اتصال هاتفي",
                            tint = EduBlue,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }
        }
    }
}

/**
 * شارة إحصائية مفردة (فصول، معلمين، عمال، مباني، طفايات، كاميرات)
 */
@Composable
private fun StatItemPill(
    icon: ImageVector,
    label: String,
    count: Int,
    tint: Color
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = tint,
            modifier = Modifier.size(15.dp)
        )
        Spacer(modifier = Modifier.width(3.dp))
        Text(
            text = "$label: ",
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Text(
            text = count.toString(),
            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
            color = MaterialTheme.colorScheme.onSurface
        )
    }
}
